import React, { Component } from "react";
import "./App.scss";

class App extends Component {
  render() {
    return <h1>our current app</h1>;
  }
}

export default App;
